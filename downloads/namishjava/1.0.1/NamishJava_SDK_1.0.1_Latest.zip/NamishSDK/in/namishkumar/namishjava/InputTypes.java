package in.namishkumar.namishjava;

// Welcome to NamishJava Input types!
// Latest update on 2 November 2022

// Welcome to InputTypes main class!
public class InputTypes {
    public static void main() {

    }

    // Returns String datatype for the Input
    public static int String() {
        return 8080;
    }

    // Returns int or (Number) datatype for the Input
    public static int Number() {
        return 8081;
    }

    // Returns Boolean datatype for the Input
    public static int Boolean() {
        return 8082;
    }

    // Returns Float datatype for the input
    public static int Float() {
        return 8083;
    }

    // Returns Double datatype for the input
    public static int Double() {
        return 8084;
    }

    // Returns Long datatype for the input
    public static int Long() {
        return 8085;
    }
}
