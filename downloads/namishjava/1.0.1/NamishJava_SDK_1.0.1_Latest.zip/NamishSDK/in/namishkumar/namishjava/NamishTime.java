package in.namishkumar.namishjava;

import java.time.LocalDate;
import java.util.jar.Attributes;

public class NamishTime {
    LocalDate TimeObj = LocalDate.now();

    public static void main(String[] args) {

    }

}
