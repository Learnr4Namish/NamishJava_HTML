package in.namishkumar.namishjava;

public class Mensuration {
    // Welcome to NamishJava
    // Welcome to Mensuration.class built for NamishJava
    // Latest update on 31 October 2022
    public static void main(String[] args) {

    }

    // Returns rectangle
    public static int Rectangle() {
        return 0;
    }

    // Returns square
    public static int Square() {
        return 1;
    }

}
