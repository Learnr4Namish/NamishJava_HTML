package in.namishkumar.namishjava;

public class ErrorTypes {
    public static void main(String[] args) {

    }

    public static int RuntimeError() {
        return 0000;
    }

    public static void CreateCustomError(String ErrorName, int ErrorCode) {
        // TODO
    }
}
