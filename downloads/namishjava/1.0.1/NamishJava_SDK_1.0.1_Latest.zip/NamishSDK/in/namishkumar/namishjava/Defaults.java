package in.namishkumar.namishjava;

// Welcome to NamishJava 1.0.0
public class Defaults {
    // The undefined
    final static String undefined = "<in.namishkumar.namishjava.Defaults.undefined>";
    final static String NaN = null;

    public static void main(String[] args) {
        // TODO
    }

    // Returns null
    public static void Null() {
        return null;
    }

    // Returns Undefined
    public static void Undefined() {
        return undefined;
    }

    // Returns NaN (Base as null)
    public static void NaN() {
        return null;
    }
}
