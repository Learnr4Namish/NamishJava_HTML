package in.namishkumar.namishjava;

// Welcome to NamishString built for NamishJava
// NamishString 1.0.1
// Last modified on 1 November 2022

// NamishString main class
public class NamishSring extends String {
    public static void main(String[] args) {
        // TODO

    }

    // Creates a new String and returns it
    public static String CreateNew(String x) {
        return x.toString();
    }

    // Converts a Object to String
    public static String ConvertToString(Object x) {
        return String.valueOf(x);
    }

}
