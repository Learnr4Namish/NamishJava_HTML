package in.namishkumar.namishjava;

// Welcome to NamishNumber.class!
// NamishNumber built for NamishJava
// Latest update (modifications) on 1 November 2022

// NamishNumber main class
public class NamishNumber {
    public static void main(String[] args) {
        // TODO
    }

    // Creates a new int and returns it
    public static int CreateNewInt(int x) {
        return x;
    }

    // Creates a new double and returns it
    public static double CreateNewDouble(double x) {
        return x;
    }

}
