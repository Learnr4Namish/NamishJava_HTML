package in.namishkumar.namishjava;

public class NamishLoop {
    public static void main(String[] args) {

    }

    
}
