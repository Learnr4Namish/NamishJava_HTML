package in.namishkumar.namishjava;

// Welcome to NamishJava 1.0.1!
// Welcome to ArraysTool.
// ArraysTool main class
public class ArraysTool {
    public static void main(String[] args) {

    }

    // Class for StringsArray
    public class StringsArray {

    }
    // Loops all the items of an array.
    /* ||NOTICE|| ListAll() void doesn't return any array. It is a void! */

}
